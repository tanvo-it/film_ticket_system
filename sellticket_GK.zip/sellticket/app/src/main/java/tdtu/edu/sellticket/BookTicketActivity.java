package tdtu.edu.sellticket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.ViewGroup;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import android.app.DatePickerDialog;
import java.util.Calendar;

public class BookTicketActivity extends AppCompatActivity {
    private ImageView settingsIcon;
    private ImageView profileImage;
    private TextView admin;
    private TextView search;// Add this line
    private TextView editprofile;
    private LinearLayout movieListLayout;
    private LinearLayout expandMenu;
    private ImageView settingsIconMenu;
    private FirebaseFirestore db;
    private ScrollView cinemaListContainer;
    private Map<String, String> showtimeIdsMap = new HashMap<>();
    private TextView usernameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_ticket);

        db = FirebaseFirestore.getInstance();
        cinemaListContainer = findViewById(R.id.cinema_list_container);

        // Initialize views
        settingsIcon = findViewById(R.id.settings_icon);
        profileImage = findViewById(R.id.profile_image);
        expandMenu = findViewById(R.id.expand_menu);
        settingsIconMenu = findViewById(R.id.settings_icon_menu);
        admin = findViewById(R.id.admin); // Initialize admin TextView
        search = findViewById(R.id.action_search);
        editprofile = findViewById(R.id.edit_profile);
        usernameTextView = findViewById(R.id.text_view_username);

        // Retrieve the document ID from the intent
        String movies_id = getIntent().getStringExtra("movies_id");
        String user_id = getIntent().getStringExtra("user_id");


        String currentDateFormatted = getCurrentDateFormatted();
        TextView dateValueTextView = findViewById(R.id.date_value);
        dateValueTextView.setText(currentDateFormatted); // Set the current date to the TextView

        // Set the default date value to the current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
        String currentDate = sdf.format(calendar.getTime());
        dateValueTextView.setText(currentDate); // Set the current date to the TextView

        // Retrieve the movie name from the intent
        String movieName = getIntent().getStringExtra("title");
        TextView filmNameTextView = findViewById(R.id.film_name_book);
        filmNameTextView.setText(movieName); // Set the movie name to the TextView

        // Fetch User Details
        db.collection("users").document(user_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fullName = documentSnapshot.getString("full_name");
                        usernameTextView.setText(fullName);
                    }
                })
                .addOnFailureListener(e -> {
                    usernameTextView.setText("User not found"); // Handle error
                });

        // Set click listener for settings icon
        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.VISIBLE);
            }
        });

        // Set click listener for settings_icon_menu to hide the expand_menu
        settingsIconMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.GONE);
            }
        });

        // Set click listener for profile_image to navigate to EditProfileActivity
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookTicketActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for editprofile TextView to navigate to ManageDataActivity
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookTicketActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for admin TextView to navigate to ManageDataActivity
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookTicketActivity.this, ManageDataActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookTicketActivity.this, SearchActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Listen for date selection changes
        dateValueTextView.setOnClickListener(view -> {
            // Get the current date
            int year = calendar.get(Calendar.YEAR); // Use the already declared calendar
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // Create a DatePickerDialog
            DatePickerDialog datePickerDialog = new DatePickerDialog(BookTicketActivity .this,
                    (datePicker, selectedYear, selectedMonth, selectedDay) -> {
                        // Format the selected date
                        String selectedDate = String.format(Locale.getDefault(), "%02d %s %d", selectedDay,
                                new SimpleDateFormat("MMMM", Locale.getDefault()).format(new Date(selectedYear - 1900, selectedMonth, selectedDay)),
                                selectedYear);
                        dateValueTextView.setText(selectedDate);
                        fetchShowtimesAndCinemas(movies_id, selectedDate, user_id); // Fetch showtimes for the selected date
                    }, year, month, day);

            datePickerDialog.show(); // Show the date picker dialog
        });

        // Set click listener for Log out TextView
        TextView logOutTextView = findViewById(R.id.button_logout); // Initialize the Log out TextView
        logOutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear user session data (if you are using SharedPreferences)
                SharedPreferences sharedPreferences = getSharedPreferences("YourPrefsName", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clear all data
                editor.apply();

                // Start the LoginActivity
                Intent intent = new Intent(BookTicketActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

        // Fetch showtimes and cinemas for the current date
        fetchShowtimesAndCinemas(movies_id, currentDateFormatted, user_id);
    }

    private String getCurrentDateFormatted() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
        return sdf.format(calendar.getTime());
    }

    private void fetchShowtimesAndCinemas(String movies_id, String selectedDate, String user_id) {
        // Parse selectedDate into a usable format
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
        SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        try {
            Date date = sdf.parse(selectedDate);
            String formattedDate = dbDateFormat.format(date);

            db.collection("showtimes")
                    .whereEqualTo("movie_id", movies_id)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Set<String> cinemaIds = new HashSet<>();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Date showtimeDate = document.getTimestamp("showtime").toDate();
                                String showtimeDateStr = dbDateFormat.format(showtimeDate);

                                if (formattedDate.equals(showtimeDateStr)) {
                                    cinemaIds.add(document.getString("cinema_id"));
                                }
                            }
                            fetchCinemas(cinemaIds, movies_id, user_id); // Pass movieId here
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fetchShowtimeForCinema(String cinemaId, TextView showtimeFilm, String movies_id) {
        db.collection("showtimes")
                .whereEqualTo("cinema_id", cinemaId)
                .whereEqualTo("movie_id", movies_id) // Use the movieId you have
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null && !task.getResult().isEmpty()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Retrieve the showtime ID
                            String showtime_id = document.getId();
                            showtimeIdsMap.put(cinemaId, showtime_id);

                            // Assuming we only want the first showtime found
                            Date showtimeDate = document.getTimestamp("showtime").toDate();
                            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                            String formattedShowtime = sdf.format(showtimeDate);
                            showtimeFilm.setText(formattedShowtime);
                            break; // Exit after the first showtime
                        }
                    } else {
                        showtimeFilm.setText("No showtimes available");
                    }
                });
    }

    private void fetchCinemas(Set<String> cinemaIds, String movies_id, String user_id) {
        cinemaListContainer.removeAllViews();

        // Create a LinearLayout to hold all cinema views
        LinearLayout cinemasContainer = new LinearLayout(this);
        cinemasContainer.setOrientation(LinearLayout.VERTICAL); // Set orientation to vertical

        for (String cinemaId : cinemaIds) {
            db.collection("cinemas").document(cinemaId).get().addOnSuccessListener(document -> {
                if (document.exists()) {
                    String name = document.getString("name");
                    String address = document.getString("address");

                    // Create a new view for the cinema
                    View cinemaView = getLayoutInflater().inflate(R.layout.cinema_item, cinemasContainer, false);

                    TextView cinemaName = cinemaView.findViewById(R.id.cinema_name);
                    TextView cinemaAddress = cinemaView.findViewById(R.id.cinema_address);
                    TextView showtimeFilm = cinemaView.findViewById(R.id.showtimefilm);
                    Button bookTicketButton = cinemaView.findViewById(R.id.book_ticket_button);

                    cinemaName.setText(name);
                    cinemaAddress.setText(address);

                    // Fetch the showtime for this cinema
                    fetchShowtimeForCinema(cinemaId, showtimeFilm, movies_id);

                    // Set OnClickListener for the book_ticket_button
                    bookTicketButton.setOnClickListener(view -> {
                        // Lấy showtime_id từ Map
                        String showtime_id = showtimeIdsMap.get(cinemaId);

                        // Here you would want to pass the necessary IDs to the next activity
                        Intent intent = new Intent(BookTicketActivity.this, ChooseSeatActivity.class);
                        intent.putExtra("user_id", user_id);
                        intent.putExtra("movie_id", movies_id);
                        intent.putExtra("cinema_id", cinemaId);
                        // You need to fetch or have the showtime document ID available, assuming you have it
                        intent.putExtra("showtime_id", showtime_id); // Replace with actual showtime ID
                        startActivity(intent);
                    });

                    // Add the cinema view to the cinemasContainer
                    cinemasContainer.addView(cinemaView);
                }
            });
        }

        // Finally, add the cinemasContainer to the ScrollView
        cinemaListContainer.addView(cinemasContainer);
    }
}

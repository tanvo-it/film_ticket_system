package tdtu.edu.sellticket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PaymentActivity extends AppCompatActivity {
    private ImageView settingsIcon;
    private ImageView profileImage;
    private TextView admin;
    private TextView search;// Add this line
    private TextView editprofile;
    private FirebaseFirestore db;
    private LinearLayout expandMenu;
    private ImageView settingsIconMenu;
    private ImageView appLogo;
    private Button confirmPaymentButton; // Declare the button
    private TextView usernameTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Initialize views
        settingsIcon = findViewById(R.id.settings_icon);
        profileImage = findViewById(R.id.profile_image);
        expandMenu = findViewById(R.id.expand_menu);
        settingsIconMenu = findViewById(R.id.settings_icon_menu);
        admin = findViewById(R.id.admin); // Initialize admin TextView
        search = findViewById(R.id.action_search);
        editprofile = findViewById(R.id.edit_profile);
        usernameTextView = findViewById(R.id.text_view_username);
        confirmPaymentButton = findViewById(R.id.confirm_payment_button); // Initialize the button
        appLogo = findViewById(R.id.app_logo);

        // Retrieve the data from the Intent
        String user_id = getIntent().getStringExtra("user_id");
        String movie_id = getIntent().getStringExtra("movie_id");
        String cinema_id = getIntent().getStringExtra("cinema_id");
        String showtime_id = getIntent().getStringExtra("showtime_id");
        String seat_id = getIntent().getStringExtra("seat_id");

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Fetch User Details
        db.collection("users").document(user_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fullName = documentSnapshot.getString("full_name");
                        usernameTextView.setText(fullName);
                    }
                })
                .addOnFailureListener(e -> {
                    usernameTextView.setText("User not found"); // Handle error
                });

        // Set click listener for settings icon
        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.VISIBLE);
            }
        });

        // Set click listener for settings_icon_menu to hide the expand_menu
        settingsIconMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.GONE);
            }
        });

        // Set click listener for profile_image to navigate to EditProfileActivity
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for editprofile TextView to navigate to ManageDataActivity
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for admin TextView to navigate to ManageDataActivity
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, ManageDataActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, SearchActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for Confirm Payment button
        confirmPaymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPayment(); // Call confirmPayment to handle payment
                // Remove the intent to start ChooseSeatActivity from here
            }
        });

        // Set click listener for Log out TextView
        TextView logOutTextView = findViewById(R.id.button_logout); // Initialize the Log out TextView
        logOutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear user session data (if you are using SharedPreferences)
                SharedPreferences sharedPreferences = getSharedPreferences("YourPrefsName", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clear all data
                editor.apply();

                // Start the LoginActivity
                Intent intent = new Intent(PaymentActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

        // Set click listener for the logo to navigate back to MainActivity
        appLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish(); // Finish the current activity if needed
            }
        });

        // Fetch Ticket Details
        extracted(movie_id, cinema_id, showtime_id, seat_id);
    }

    private void extracted(String movie_id, String cinema_id, String showtime_id, String seat_id) {
        fetchTicketDetails(movie_id, cinema_id, showtime_id, seat_id);
    }

    private void fetchTicketDetails(String movieId, String cinemaId, String showtimeId, String seatId) {
        // Fetch movie details
        db.collection("movies").document(movieId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String movieName = documentSnapshot.getString("title");
                        // Display movie name
                        TextView movieNameTextView = findViewById(R.id.movie_name);
                        movieNameTextView.setText(movieName);
                    }
                });

        // Fetch cinema details
        db.collection("cinemas").document(cinemaId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String cinemaName = documentSnapshot.getString("name");
                        // Display cinema name
                        TextView cinemaNameTextView = findViewById(R.id.cinema_name);
                        cinemaNameTextView.setText(cinemaName);
                    }
                });

        // Fetch showtime details
        db.collection("showtimes").document(showtimeId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        Timestamp timestamp = documentSnapshot.getTimestamp("showtime");

                        // Format the showtime
                        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy h:mm a", Locale.ENGLISH);
                        String formattedShowtime = sdf.format(timestamp.toDate());
                        TextView textViewShowtime = findViewById(R.id.showtime);
                        textViewShowtime.setText(formattedShowtime);

                        Double ticketPrice = documentSnapshot.getDouble("price"); // Assuming price is stored as a string
                        // Display ticket price
                        TextView ticketPriceTextView = findViewById(R.id.ticket_price);
                        ticketPriceTextView.setText("$" + ticketPrice);
                    }
                });

        // Display seat number
        TextView seatNumberTextView = findViewById(R.id.seat_number);
        seatNumberTextView.setText(seatId);
    }

    private void confirmPayment() {
        // Retrieve IDs from Intent
        String user_id = getIntent().getStringExtra("user_id");
        String movie_id = getIntent().getStringExtra("movie_id");
        String cinema_id = getIntent().getStringExtra("cinema_id");
        String showtime_id = getIntent().getStringExtra("showtime_id");
        String seat_id = getIntent().getStringExtra("seat_id");

        // Initialize an empty map to hold ticket details
        Map<String, Object> ticketData = new HashMap<>();

        // Fetch the current showtime details
        db.collection("showtimes").document(showtime_id).get()
                .addOnSuccessListener(showtimeSnapshot -> {
                    if (showtimeSnapshot.exists()) {
                        // Fetch current showtime data
                        int availableSeats = showtimeSnapshot.getLong("available_seats").intValue();

                        // Fetch available and unavailable seats as arrays
                        List<String> availableSeatsList = (List<String>) showtimeSnapshot.get("available");
                        List<String> unavailableSeatsList = (List<String>) showtimeSnapshot.get("unavailable");

                        // Update available seats
                        availableSeats -= 1;

                        // Update available and unavailable lists
                        if (availableSeatsList == null) {
                            availableSeatsList = new ArrayList<>();
                        }
                        if (unavailableSeatsList == null) {
                            unavailableSeatsList = new ArrayList<>();
                        }

                        availableSeatsList.remove(seat_id); // Remove chosen seat to available
                        unavailableSeatsList.add(seat_id); // Add chosen seat from unavailable

                        // Prepare the updated showtime data
                        Map<String, Object> updatedShowtimeData = new HashMap<>();
                        updatedShowtimeData.put("available_seats", availableSeats);
                        updatedShowtimeData.put("available", availableSeatsList);
                        updatedShowtimeData.put("unavailable", unavailableSeatsList);

                        // Update the showtime document in Firestore
                        db.collection("showtimes").document(showtime_id).update(updatedShowtimeData)
                                .addOnSuccessListener(aVoid -> {
                                    // Proceed with saving the ticket data
                                    saveTicketData(user_id, movie_id, cinema_id, showtime_id, seat_id, ticketData);
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(PaymentActivity.this, "Error updating showtime: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(PaymentActivity.this, "Error fetching showtime details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveTicketData(String user_id, String movie_id, String cinema_id, String showtime_id, String seat_id, Map<String, Object> ticketData) {
        // Initialize an empty map to hold ticket details
        ticketData.clear(); // Clear existing data if any

        // Fetch Cinema Details
        db.collection("cinemas").document(cinema_id).get()
                .addOnSuccessListener(cinemaSnapshot -> {
                    if (cinemaSnapshot.exists()) {
                        ticketData.put("cinema", cinemaSnapshot.getString("name"));
                    }
                    // Fetch Movie Details
                    db.collection("movies").document(movie_id).get()
                            .addOnSuccessListener(movieSnapshot -> {
                                if (movieSnapshot.exists()) {
                                    ticketData.put("movie_name", movieSnapshot.getString("title"));
                                }
                                // Fetch Showtime Details
                                db.collection("showtimes").document(showtime_id).get()
                                        .addOnSuccessListener(showtimeSnapshot -> {
                                            if (showtimeSnapshot.exists()) {
                                                ticketData.put("showtime", showtimeSnapshot.getTimestamp("showtime"));
                                                ticketData.put("price", showtimeSnapshot.getDouble("price"));
                                                ticketData.put("showtime_id", showtime_id); // Add showtime_id to ticket data
                                            }
                                            // Fetch User Email (if necessary)
                                            db.collection("users").document(user_id).get()
                                                    .addOnSuccessListener(userSnapshot -> {
                                                        if (userSnapshot.exists()) {
                                                            ticketData.put("user_email", userSnapshot.getString("email"));
                                                        }
                                                        // Add Seat Number
                                                        ticketData.put("seat_number", seat_id);
                                                        ticketData.put("date_payment", FieldValue.serverTimestamp()); // Add current timestamp
                                                        ticketData.put("payment_method", "Visa Card"); // Example method

                                                        // // Generate and save the ticket
                                                        saveTicketToFirestore(ticketData, user_id, movie_id, cinema_id, showtime_id);
                                                    })
                                                    .addOnFailureListener(e -> {
                                                        Toast.makeText(PaymentActivity.this, "Error fetching user details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                    });
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(PaymentActivity.this, "Error fetching showtime details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        });
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(PaymentActivity.this, "Error fetching movie details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(PaymentActivity.this, "Error fetching cinema details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveTicketToFirestore(Map<String, Object> ticketData, String user_id, String movie_id, String cinema_id, String showtime_id) {
        db.collection("tickets").get()
                .addOnSuccessListener(querySnapshot -> {
                    int maxId = 0;

                    // Find the highest ticket ID
                    for (DocumentSnapshot doc : querySnapshot) {
                        String ticketId = doc.getId();
                        if (ticketId.startsWith("T")) {
                            try {
                                int currentId = Integer.parseInt(ticketId.substring(1));
                                if (currentId > maxId) {
                                    maxId = currentId;
                                }
                            } catch (NumberFormatException ignored) {
                            }
                        }
                    }

                    // Generate the next ticket ID
                    String nextTicketId = "T" + String.format("%03d", maxId + 1);

                    // Save the ticket
                    db.collection("tickets").document(nextTicketId)
                            .set(ticketData)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(PaymentActivity.this, "Payment Confirmed! Ticket ID: " + nextTicketId, Toast.LENGTH_SHORT).show();

                                // Navigate to ChooseSeatActivity after confirming payment
                                Intent intent = new Intent(PaymentActivity.this, ChooseSeatActivity.class);
                                intent.putExtra("user_id", user_id);
                                intent.putExtra("movie_id", movie_id);
                                intent.putExtra("cinema_id", cinema_id);
                                intent.putExtra("showtime_id", showtime_id);
                                startActivity(intent);
                                finish(); // Finish the current activity if needed
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(PaymentActivity.this, "Error creating ticket: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(PaymentActivity.this, "Error generating ticket ID: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

}
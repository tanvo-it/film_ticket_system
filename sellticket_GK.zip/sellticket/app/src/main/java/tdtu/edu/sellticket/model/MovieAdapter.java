package tdtu.edu.sellticket.model;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
//import com.bumptech.glide.Glide; // Use Glide for loading images
import java.util.List;

import tdtu.edu.sellticket.R;
import tdtu.edu.sellticket.model.Movie;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private List<Movie> movieList;

    public MovieAdapter(List<Movie> movieList) {
        this.movieList = movieList;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_card_layout, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        Movie movie = movieList.get(position);
        holder.movieName.setText(movie.getTitle());
        holder.movieDuration.setText(movie.getDuration());
        holder.movieDate.setText(movie.getReleaseDate());
        //Glide.with(holder.itemView.getContext()).load(movie.getPosterUrl()).into(holder.moviePoster);

        holder.bookTicketButton.setOnClickListener(v -> {
            // Handle the ticket booking action here
        });
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    static class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView movieName, movieDuration, movieDate;
        ImageView moviePoster;
        Button bookTicketButton;

        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            movieName = itemView.findViewById(R.id.movie_name);
            movieDuration = itemView.findViewById(R.id.movie_duration);
            movieDate = itemView.findViewById(R.id.movie_date);
            moviePoster = itemView.findViewById(R.id.movie_poster);
            bookTicketButton = itemView.findViewById(R.id.book_ticket_button);
        }
    }
}
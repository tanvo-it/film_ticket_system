package tdtu.edu.sellticket.model;

public class User {
    private String account_creation_date;
    private String documentId; // Firestore document ID
    private String email; // User's email
    private String full_name; // User's full name
    private String password; // User's password
    private String phone_number; // User's phone number
    private String role; // User's role

    public User(String account_creation_date, String email, String full_name, String password, String phone_number, String role) {
        this.account_creation_date = account_creation_date;
        this.email = email;
        this.full_name = full_name;
        this.password = password;
        this.phone_number = phone_number;
        this.role = role;
    }

    public User(String fullName, String email, String phoneNumber, String role) {

        this.full_name = fullName;
        this.email = email;
        this.phone_number = phoneNumber;
        this.role = role;
    }

    // Getters and setters for each attribute
    public String getAccountCreationDate() {
        return account_creation_date;
    }

    public void setAccountCreationDate(String account_creation_date) {
        this.account_creation_date = account_creation_date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return full_name;
    }

    public void setFullName(String full_name) {
        this.full_name = full_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phone_number;
    }

    public void setPhoneNumber(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
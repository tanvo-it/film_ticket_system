package tdtu.edu.sellticket;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class SavePictureActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button btnSelectImage, btnSaveImage;
    private Bitmap selectedImageBitmap = null;
    private static final int REQUEST_CODE_PICK_IMAGE = 100;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_picture);

        imageView = findViewById(R.id.imageView);
        btnSelectImage = findViewById(R.id.btnSelectImage);
        btnSaveImage = findViewById(R.id.btnSaveImage);

        firestore = FirebaseFirestore.getInstance();

        btnSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        btnSaveImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveImageToFirestore();
            }
        });
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri imageUri = data.getData();
                try {
                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                    selectedImageBitmap = BitmapFactory.decodeStream(inputStream);
                    imageView.setImageBitmap(selectedImageBitmap);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void saveImageToFirestore() {
        if (selectedImageBitmap == null) {
            Toast.makeText(this, "Please select an image first!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Chuyển đổi Bitmap sang Base64
        String base64Image = encodeImageToBase64(selectedImageBitmap);

        // Lấy document ID mới
        firestore.collection("images").get().addOnSuccessListener(queryDocumentSnapshots -> {
            int newIdNumber = queryDocumentSnapshots.size() + 1;
            String newId = "P" + String.format("%03d", newIdNumber);

            // Tạo dữ liệu để lưu trữ
            Map<String, String> data = new HashMap<>();
            data.put("image_code", base64Image);

            // Lưu vào Firestore
            firestore.collection("images").document(newId).set(data)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(SavePictureActivity.this, "Image saved with ID: " + newId, Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(SavePictureActivity.this, "Failed to save image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Error retrieving documents: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private String encodeImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }
}


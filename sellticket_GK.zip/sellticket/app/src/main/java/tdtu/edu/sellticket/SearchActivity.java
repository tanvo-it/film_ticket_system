package tdtu.edu.sellticket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

import tdtu.edu.sellticket.model.Movie;
import tdtu.edu.sellticket.model.MovieAdapter;

public class SearchActivity extends AppCompatActivity {

    private ImageView settingsIcon;
    private ImageView profileImage;
    private TextView admin;
    private TextView search;// Add this line
    private TextView editprofile;
    private FirebaseFirestore db;
    private LinearLayout expandMenu;
    private ImageView settingsIconMenu;
    private ImageView ticket_icon;
    private EditText searchInput;
    private RecyclerView recyclerView;
    private MovieAdapter movieAdapter;
    private List<Movie> movieList;
    private List<Movie> filteredMovieList;
    private TextView usernameTextView;
    private ImageView appLogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // Retrieve the document ID from the intent
        String user_id = getIntent().getStringExtra("user_id");

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize views
        settingsIcon = findViewById(R.id.settings_icon);
        profileImage = findViewById(R.id.profile_image);
        expandMenu = findViewById(R.id.expand_menu);
        settingsIconMenu = findViewById(R.id.settings_icon_menu);
        admin = findViewById(R.id.admin); // Initialize admin TextView
        search = findViewById(R.id.action_search);
        editprofile = findViewById(R.id.edit_profile);
        ticket_icon = findViewById(R.id.ticket_icon);
        appLogo = findViewById(R.id.app_logo);
        usernameTextView = findViewById(R.id.text_view_username);

        searchInput = findViewById(R.id.search_input);
        recyclerView = findViewById(R.id.recycler_view);

        movieList = new ArrayList<>();
        filteredMovieList = new ArrayList<>();
        movieAdapter = new MovieAdapter(filteredMovieList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(movieAdapter);

        // Fetch User Details
        db.collection("users").document(user_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fullName = documentSnapshot.getString("full_name");
                        usernameTextView.setText(fullName);
                    }
                })
                .addOnFailureListener(e -> {
                    usernameTextView.setText("User not found"); // Handle error
                });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterMovies(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Set click listener for settings icon
        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.VISIBLE);
            }
        });

        // Set click listener for settings_icon_menu to hide the expand_menu
        settingsIconMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.GONE);
            }
        });

        // Set click listener for profile_image to navigate to EditProfileActivity
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for ticket_image to navigate to TicketActivity
        ticket_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, TicketActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for editprofile TextView to navigate to ManageDataActivity
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for admin TextView to navigate to ManageDataActivity
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, ManageDataActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, SearchActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        appLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish(); // Finish the current activity if needed
            }
        });

        // Set click listener for Log out TextView
        TextView logOutTextView = findViewById(R.id.button_logout); // Initialize the Log out TextView
        logOutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear user session data (if you are using SharedPreferences)
                SharedPreferences sharedPreferences = getSharedPreferences("YourPrefsName", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clear all data
                editor.apply();

                // Start the LoginActivity
                Intent intent = new Intent(SearchActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

        fetchMoviesFromDatabase(); // Fetch movies from Firestore
    }

    private void fetchMoviesFromDatabase() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("movies")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String documentId = document.getId();
                            String title = document.getString("title");
                            String actors = document.getString("actors");
                            String director = document.getString("director");
                            String duration = document.getString("duration");
                            String genre = document.getString("genre");
                            String posterUrl = document.getString("poster_url");
                            String releaseDate = document.getString("release_date");
                            String synopsis = document.getString("synopsis");

                            Movie movie = new Movie(documentId, title, actors, director, duration, genre, posterUrl, releaseDate, synopsis);
                            movieList.add(movie);
                        }
                        filteredMovieList.addAll(movieList); // Initialize filtered list
                        movieAdapter.notifyDataSetChanged(); // Notify adapter of data change
                    } else {
                        Log.w("FetchMovies", "Error getting documents.", task.getException());
                    }
                });
    }

    private void filterMovies(String query) {
        filteredMovieList.clear();
        if (query.isEmpty()) {
            filteredMovieList.addAll(movieList);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (Movie movie : movieList) {
                if (movie.getTitle().toLowerCase().contains(lowerCaseQuery)) {
                    filteredMovieList.add(movie);
                }
            }
        }
        movieAdapter.notifyDataSetChanged();
    }
}
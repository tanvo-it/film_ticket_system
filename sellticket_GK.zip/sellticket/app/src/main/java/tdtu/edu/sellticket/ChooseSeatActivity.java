package tdtu.edu.sellticket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ChooseSeatActivity extends AppCompatActivity {
    private ImageView settingsIcon;
    private ImageView profileImage;
    private TextView admin;
    private TextView search;// Add this line
    private TextView editprofile;
    private FirebaseFirestore db;
    private LinearLayout expandMenu;
    private ImageView settingsIconMenu;
    private GridLayout seatsLayout; // Declare GridLayout for seats
    private TextView cinemaNameTextView;
    private TextView cinemaNumberTextView;
    private TextView showtimeTextView;
    private TextView usernameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_seat);

        // Retrieve the data from the Intent
        String user_id = getIntent().getStringExtra("user_id");
        String movie_id = getIntent().getStringExtra("movie_id");
        String cinema_id = getIntent().getStringExtra("cinema_id");
        String showtimeId = getIntent().getStringExtra("showtime_id");

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize views
        settingsIcon = findViewById(R.id.settings_icon);
        profileImage = findViewById(R.id.profile_image);
        expandMenu = findViewById(R.id.expand_menu);
        settingsIconMenu = findViewById(R.id.settings_icon_menu);
        admin = findViewById(R.id.admin); // Initialize admin TextView
        search = findViewById(R.id.action_search);
        editprofile = findViewById(R.id.edit_profile);
        cinemaNameTextView = findViewById(R.id.cinema_name_book);
        cinemaNumberTextView = findViewById(R.id.cinema_number);
        showtimeTextView = findViewById(R.id.showtime);
        usernameTextView = findViewById(R.id.text_view_username);
        seatsLayout = findViewById(R.id.seats_layout);

        // Fetch User Details
        db.collection("users").document(user_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fullName = documentSnapshot.getString("full_name");
                        usernameTextView.setText(fullName);
                    }
                })
                .addOnFailureListener(e -> {
                    usernameTextView.setText("User not found"); // Handle error
                });

        // Fetch Cinema Details
        db.collection("cinemas").document(cinema_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String cinemaName = documentSnapshot.getString("name");
                        cinemaNameTextView.setText(cinemaName);
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle errors
                });

// Fetch Showtime Details
        db.collection("showtimes").document(showtimeId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        long cinemaNumber = documentSnapshot.getLong("cinema_number");
                        Timestamp timestamp = documentSnapshot.getTimestamp("showtime");

                        // Format the showtime
                        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy h:mm a", Locale.ENGLISH);
                        String formattedShowtime = sdf.format(timestamp.toDate());

                        // Fetch the number of seats
                        long numberOfSeats = documentSnapshot.getLong("seats");

                        // Retrieve available and unavailable arrays
                        List<String> available = (List<String>) documentSnapshot.get("available");
                        List<String> unavailable = (List<String>) documentSnapshot.get("unavailable");

                        // Generate seat views
                        createSeatItem(numberOfSeats, available, unavailable, user_id, movie_id, cinema_id, showtimeId);

                        cinemaNumberTextView.setText("Cinema " + cinemaNumber);
                        showtimeTextView.setText(formattedShowtime);
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle errors
                });

        // Set click listener for settings icon
        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.VISIBLE);
            }
        });

        // Set click listener for settings_icon_menu to hide the expand_menu
        settingsIconMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.GONE);
            }
        });

        // Set click listener for profile_image to navigate to EditProfileActivity
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseSeatActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for editprofile TextView to navigate to ManageDataActivity
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseSeatActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for admin TextView to navigate to ManageDataActivity
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseSeatActivity.this, ManageDataActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseSeatActivity.this, SearchActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for Log out TextView
        TextView logOutTextView = findViewById(R.id.button_logout); // Initialize the Log out TextView
        logOutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear user session data (if you are using SharedPreferences)
                SharedPreferences sharedPreferences = getSharedPreferences("YourPrefsName", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clear all data
                editor.apply();

                // Start the LoginActivity
                Intent intent = new Intent(ChooseSeatActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

    }

    // Method to generate seat views
    private void createSeatItem(long numberOfSeats, List<String> available, List<String> unavailable, String user_id, String movie_id, String cinema_id, String showtimeId) {
        for (int i = 1; i <= numberOfSeats; i++) {
            // Create a new TextView for each seat
            TextView seatView = new TextView(this);

            // Generate the seat ID (e.g., A01, A02, ...)
            String seatId = "A" + String.format("%02d", i);

            // Set unique ID for the view
            seatView.setId(View.generateViewId());

            // Configure layout parameters
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = GridLayout.LayoutParams.WRAP_CONTENT;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            int margin = 4;
            params.setMargins(margin, margin, margin, margin);
            seatView.setLayoutParams(params);

            // Set text and styles for the seat
            seatView.setGravity(Gravity.CENTER);
            seatView.setPadding(60, 60, 60, 60);
            seatView.setText(seatId);
            seatView.setTextSize(16);
            seatView.setTextColor(Color.BLACK);

            // Determine seat color based on availability
            if (available != null && available.contains(seatId)) {
                seatView.setBackgroundColor(Color.parseColor("#008000")); // Available seats
                seatView.setTextColor(Color.WHITE);
                seatView.setTypeface(null, Typeface.BOLD);

                // Set OnClickListener for available seats to navigate to PaymentActivity
                seatView.setOnClickListener(v -> {
                    Intent intent = new Intent(ChooseSeatActivity.this, PaymentActivity.class);
                    intent.putExtra("user_id", user_id);
                    intent.putExtra("movie_id", movie_id);
                    intent.putExtra("cinema_id", cinema_id);
                    intent.putExtra("showtime_id", showtimeId);
                    intent.putExtra("seat_id", seatId); // Pass the selected seat ID
                    startActivity(intent);
                });

            } else if (unavailable != null && unavailable.contains(seatId)) {
                seatView.setBackgroundColor(Color.parseColor("#e30613")); // Unavailable seats
                seatView.setTextColor(Color.WHITE);
                seatView.setTypeface(null, Typeface.BOLD);

                // Set OnClickListener for unavailable seats to show a message
                seatView.setOnClickListener(v -> {
                    Toast.makeText(ChooseSeatActivity.this, "This seat is no longer available.", Toast.LENGTH_SHORT).show();
                });

            } else {
                seatView.setBackgroundColor(Color.GRAY); // Neutral/default color
                seatView.setTypeface(null, Typeface.BOLD); // Neutral/default style
            }

            // Add seat to the GridLayout
            seatsLayout.addView(seatView);
        }
    }
}
package tdtu.edu.sellticket;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import tdtu.edu.sellticket.model.User;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextFullName, editTextEmail, editTextPassword, editTextPhoneNumber;
    private Button buttonRegister;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize UI components
        editTextFullName = findViewById(R.id.editTextFullName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Set up the register button click listener
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser ();
            }
        });
    }

    private void registerUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String full_name = editTextFullName.getText().toString().trim();
        String phone_number = editTextPhoneNumber.getText().toString().trim();
        String role = "user"; // Default role

        if (email.isEmpty() || password.isEmpty() || full_name.isEmpty() || phone_number.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the current date and format it as "YYYY-MM-DD"
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String account_creation_date = currentDate.format(formatter);

        // Query the users collection to find the next available ID
        db.collection("users").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        int nextId = 1; // Start from 1
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String documentId = document.getId();
                            if (documentId.startsWith("U")) {
                                try {
                                    int currentId = Integer.parseInt(documentId.substring(1)); // Extract the number
                                    if (currentId >= nextId) {
                                        nextId = currentId + 1; // Increment to find the next ID
                                    }
                                } catch (NumberFormatException e) {
                                    // Handle the case where the ID is not in the expected format
                                }
                            }
                        }

                        // Create the new user ID
                        String newUserId = "U" + String.format("%03d", nextId); // Format ID as UXXX

                        // Create a new user object
                        User newUser = new User(account_creation_date, email, full_name, password, phone_number, role);

                        // Save the new user to Firestore
                        db.collection("users").document(newUserId).set(newUser)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                                    finish(); // Close the registration activity
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(RegisterActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });

                    } else {
                        Toast.makeText(RegisterActivity.this, "Error getting users: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

}
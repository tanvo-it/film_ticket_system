package tdtu.edu.sellticket;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class TicketActivity extends AppCompatActivity {
    private ImageView settingsIcon;
    private ImageView profileImage;
    private TextView admin;
    private TextView search;// Add this line
    private TextView editprofile;
    private FirebaseFirestore db;
    private LinearLayout expandMenu;
    private ImageView settingsIconMenu;
    private LinearLayout ticketListLayout;
    private ImageView appLogo;
    private TextView usernameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);

        // Retrieve the document ID from the intent
        String user_id = getIntent().getStringExtra("user_id");

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();
        ticketListLayout = findViewById(R.id.ticket_layout);

        // Initialize views
        settingsIcon = findViewById(R.id.settings_icon);
        profileImage = findViewById(R.id.profile_image);
        expandMenu = findViewById(R.id.expand_menu);
        settingsIconMenu = findViewById(R.id.settings_icon_menu);
        admin = findViewById(R.id.admin); // Initialize admin TextView
        search = findViewById(R.id.action_search);
        editprofile = findViewById(R.id.edit_profile);
        appLogo = findViewById(R.id.app_logo);
        usernameTextView = findViewById(R.id.text_view_username);

        // Fetch User Details
        db.collection("users").document(user_id).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fullName = documentSnapshot.getString("full_name");
                        usernameTextView.setText(fullName);
                    }
                })
                .addOnFailureListener(e -> {
                    usernameTextView.setText("User not found"); // Handle error
                });

        // Set click listener for settings icon
        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.VISIBLE);
            }
        });

        // Set click listener for settings_icon_menu to hide the expand_menu
        settingsIconMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandMenu.setVisibility(View.GONE);
            }
        });

        // Set click listener for profile_image to navigate to EditProfileActivity
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TicketActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for editprofile TextView to navigate to ManageDataActivity
        editprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TicketActivity.this, EditProfileActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for admin TextView to navigate to ManageDataActivity
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TicketActivity.this, ManageDataActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TicketActivity.this, SearchActivity.class);
                intent.putExtra("user_id", user_id);
                startActivity(intent);
            }
        });

        // Set click listener for Log out TextView
        TextView logOutTextView = findViewById(R.id.button_logout); // Initialize the Log out TextView
        logOutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear user session data (if you are using SharedPreferences)
                SharedPreferences sharedPreferences = getSharedPreferences("YourPrefsName", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Clear all data
                editor.apply();

                // Start the LoginActivity
                Intent intent = new Intent(TicketActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

        // Set click listener for the logo to navigate back to MainActivity
        appLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TicketActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear the activity stack
                intent.putExtra("user_id", user_id);
                startActivity(intent);
                finish(); // Finish the current activity if needed
            }
        });

        getUserEmail(user_id);
    }

    private void getUserEmail(String userId) {
        db.collection("users")
                .document(userId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                String userEmail = document.getString("email");
                                // Now get the tickets for this email
                                getUserTickets(userEmail);
                            }
                        }
                    }
                });
    }

    private void getUserTickets(String userEmail) {
        db.collection("tickets")
                .whereEqualTo("user_email", userEmail)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            int ticketCount = 0; // Initialize a counter
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                ticketCount++; // Increment the counter for each ticket
                                addTicketItem(document);
                            }
                            Log.d("TicketActivity", "Number of tickets retrieved: " + ticketCount);
                        } else {
                            Log.e("TicketActivity", "Error getting tickets: ", task.getException());
                        }
                    }
                });
    }

    private void addTicketItem(QueryDocumentSnapshot ticket) {
        // Inflate the ticket item layout
        LayoutInflater inflater = LayoutInflater.from(this);
        View ticketItemView = inflater.inflate(R.layout.ticket_item, ticketListLayout, false);

        // Populate the ticket item view with data
        TextView movieNameTextView = ticketItemView.findViewById(R.id.movie_name);
        TextView cinemaNameTextView = ticketItemView.findViewById(R.id.cinema_name);
        TextView showtimeTextView = ticketItemView.findViewById(R.id.showtime);
        TextView seatNumberTextView = ticketItemView.findViewById(R.id.seat_number);
        TextView ticketPriceTextView = ticketItemView.findViewById(R.id.ticket_price);
        TextView datePaymentTextView = ticketItemView.findViewById(R.id.date_payment);
        Button cancelTicketButton = ticketItemView.findViewById(R.id.cancel_ticket_button);

        movieNameTextView.setText(ticket.getString("movie_name"));
        cinemaNameTextView.setText(ticket.getString("cinema"));

        // Format the showtime
        Timestamp timestamp = ticket.getTimestamp("showtime"); // Assuming showtime is stored as a Timestamp in Firestore
        if (timestamp != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy h:mm a", Locale.ENGLISH);
            String formattedShowtime = sdf.format(timestamp.toDate());
            showtimeTextView.setText(formattedShowtime);
        } else {
            showtimeTextView.setText("Showtime: Not available");
        }

        seatNumberTextView.setText(ticket.getString("seat_number"));
        ticketPriceTextView.setText("$" + ticket.getDouble("price"));

        // Format the date_payment
        Timestamp datePaymentTimestamp = ticket.getTimestamp("date_payment"); // Retrieve date_payment as Timestamp
        if (datePaymentTimestamp != null) {
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy h:mm a", Locale.ENGLISH);
            String formattedDatePayment = outputFormat.format(datePaymentTimestamp.toDate()); // Format the Timestamp
            datePaymentTextView.setText(formattedDatePayment);
        } else {
            datePaymentTextView.setText("Date Payment: Not available");
        }

        // Retrieve the ticket ID
        String ticketId = ticket.getId(); // Get the ticket ID

        // Set click listener for cancel ticket button
        cancelTicketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show confirmation dialog
                new AlertDialog.Builder(TicketActivity.this)
                        .setTitle("Confirm Cancellation")
                        .setMessage("Are you sure you want to cancel this ticket?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // If the user confirms, cancel the ticket
                                cancelTicket(ticketId);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // If the user cancels, dismiss the dialog
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });

        // Add the populated view to the ticket layout
        ticketListLayout.addView(ticketItemView);
    }

    private void cancelTicket(String ticketId) {
        // Reference to Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Fetch the ticket details
        db.collection("tickets").document(ticketId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        // Get the seat number and showtime ID from the ticket document
                        String seatNumber = documentSnapshot.getString("seat_number");
                        String showtimeId = documentSnapshot.getString("showtime_id");

                        // Now fetch the showtime document to update its data
                        db.collection("showtimes").document(showtimeId).get()
                                .addOnSuccessListener(showtimeSnapshot -> {
                                    if (showtimeSnapshot.exists()) {
                                        // Get the current values from the showtime document
                                        int availableSeats = showtimeSnapshot.getLong("available_seats").intValue();
                                        List<String> availableSeatsList = (List<String>) showtimeSnapshot.get("available");
                                        List<String> unavailableSeatsList = (List<String>) showtimeSnapshot.get("unavailable");

                                        // Update the available seats
                                        availableSeats += 1;
                                        availableSeatsList.add(seatNumber);
                                        unavailableSeatsList.remove(seatNumber);

                                        // Create a map for the updated data
                                        Map<String, Object> updatedShowtimeData = new HashMap<>();
                                        updatedShowtimeData.put("available_seats", availableSeats);
                                        updatedShowtimeData.put("available", availableSeatsList);
                                        updatedShowtimeData.put("unavailable", unavailableSeatsList);

                                        // Update the showtime document with the new data
                                        db.collection("showtimes").document(showtimeId).update(updatedShowtimeData)
                                                .addOnSuccessListener(aVoid -> {
                                                    // Optionally delete the ticket document
                                                    db.collection("tickets").document(ticketId).delete()
                                                            .addOnSuccessListener(aVoid1 -> {
                                                                Toast.makeText(TicketActivity.this, "Ticket cancelled successfully!", Toast.LENGTH_SHORT).show();
                                                                recreate(); // Reload the activity after cancellation
                                                            })
                                                            .addOnFailureListener(e -> {
                                                                Toast.makeText(TicketActivity.this, "Error deleting ticket: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                            });
                                                })
                                                .addOnFailureListener(e -> {
                                                    Toast.makeText(TicketActivity.this, "Error updating showtime: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                                });
                                    } else {
                                        Toast.makeText(TicketActivity.this, "Showtime not found!", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(TicketActivity.this, "Error fetching showtime details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        Toast.makeText(TicketActivity.this, "Ticket not found!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(TicketActivity.this, "Error fetching ticket details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

}